### What are you trying to do?


### What did you expect to happen?


### What actually happened?


### What hardware and software are you using (including version numbers)?

<!-- Tip: copy and paste the output of `ev3dev-sysinfo -m` here -->

