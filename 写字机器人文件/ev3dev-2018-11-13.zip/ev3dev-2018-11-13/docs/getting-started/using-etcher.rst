================================
Using Etcher to Flash an SD Card
================================

.. todo:: Make this page pretty with screenshots and stuff.

1. If you have not already, download and install Etcher.

2. Start Etcher.

3. Open the ev3dev disk image that you downloaded.

  .. tip:: You don't need to unzip the image.

4. Plug the SD card into your computer. Etcher should automatically detect it.

5. Click the flash button. Etcher will tell you when it is done an it is
   safe to remove the SD card.

   .. tip:: If Etcher tells you that the validation failed, you probably
      have a defective SD card and should try an different one.
