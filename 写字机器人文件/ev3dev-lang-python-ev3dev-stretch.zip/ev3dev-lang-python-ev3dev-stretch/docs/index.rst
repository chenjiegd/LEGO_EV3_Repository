.. include:: ../README.rst

.. rubric:: Contents

.. toctree::
   :maxdepth: 3

   upgrading-to-stretch
   spec
   rpyc
   faq
