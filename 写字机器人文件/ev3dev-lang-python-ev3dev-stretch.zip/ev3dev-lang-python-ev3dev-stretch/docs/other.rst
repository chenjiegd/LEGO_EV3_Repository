:orphan:

Other classes
=============

Button
------

See :py:class:`ev3dev2.button.Button`.

Leds
----

See :ref:`led-classes`.

Power Supply
------------

See :py:class:`ev3dev2.power.PowerSupply`.

Sound
-----

See :py:class:`ev3dev2.sound.Sound`.

Display
-------

See :py:class:`ev3dev2.display.Display`.

Lego Port
---------

See :py:class:`ev3dev2.port.LegoPort`.