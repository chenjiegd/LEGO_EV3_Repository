
OUTPUT_A = 'outA'
OUTPUT_B = 'outB'
OUTPUT_C = 'outC'
OUTPUT_D = 'outD'

INPUT_1 = 'in1'
INPUT_2 = 'in2'
INPUT_3 = 'in3'
INPUT_4 = 'in4'

BUTTONS_FILENAME = None
EVDEV_DEVICE_NAME = None

LEDS = {}
LED_GROUPS = {}
LED_COLORS = {}
